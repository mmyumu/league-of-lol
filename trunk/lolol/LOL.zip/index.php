<?php
	require_once('conf.php');
	require_once('db.php');


?>